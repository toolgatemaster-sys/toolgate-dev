// apps/gateway/__tests__/retry_notify.test.ts
import { describe, it, expect } from "vitest";

// NOTE: This is a skeleton. Wire it to your Fastify test harness (createServer, inject, etc.).
// DO NOT add new dependencies. Keep it inside the Day 6 cage.

describe("Day 6 — retry & notifications", () => {
  it("first request -> pending (202)", async () => {
    expect(true).toBe(true);
    // TODO:
    // - start app with enforcement + approvals + notify disabled
    // - POST /v1/tools/http.post with body that maps to pending (policy stub)
    // - expect 202 with {decision:'pending', approval_id}
  });

  it("after approve, retry same bodyHash -> 200 allow", async () => {
    expect(true).toBe(true);
    // TODO:
    // - approve via POST /api/approvals/:id/approve
    // - retry same request (same bodyHash) -> expect 200 allow
  });

  it("after deny, retry same bodyHash -> 403 deny", async () => {
    expect(true).toBe(true);
  });

  it("after expire, retry same bodyHash -> 403 deny", async () => {
    expect(true).toBe(true);
  });

  it("sends notification on approve/deny/expire (mock webhook)", async () => {
    expect(true).toBe(true);
    // TODO:
    // - set process.env.TOOLGATE_WEBHOOK_URL to http://localhost:<mock>
    // - capture POST payloads and assert { id, status, agentId, ctx, ts }
  });
});
