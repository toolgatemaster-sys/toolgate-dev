# Day 6 — Implementation Guide

1) `packages/core/approval.ts`: add `hashBody(body)` helper.
2) `apps/gateway/src/approvals.store.ts`: add bodyHash in ctx + index + findByBodyHash.
3) `apps/gateway/src/enforcement.ts`: compute bodyHash; reuse decision if exists.
4) `apps/gateway/src/approvals.notify.ts`: send webhook on approve/deny/expire.
5) Tests in `apps/gateway/__tests__/retry_notify.test.ts`.
