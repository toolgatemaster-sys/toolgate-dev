# Day 6 — Tasks
- [ ] hashBody helper
- [ ] bodyHash index
- [ ] enforcement retry logic
- [ ] webhook notify
- [ ] tests retry+notify
- [ ] all tests green
- [ ] PR ready
