# Day 6 — Retry & Notifications PR

## Summary
- bodyHash retry flow
- Notifications on approval state changes
- Tests passing

## Scope (Cage)
- apps/gateway/src
- apps/gateway/__tests__
- packages/core
- md/day6
- scripts

## Tests
```
vitest run apps/gateway/__tests__/retry_notify.test.ts
```

## Checklist
- [ ] bodyHash helper
- [ ] Store indexing
- [ ] Enforcement reuse
- [ ] Webhook notify
- [ ] Tests green
- [ ] No files outside cage
