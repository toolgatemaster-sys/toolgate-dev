You are Cursor working on Day 6. Implement retry/idempotency via bodyHash and webhook notifications.
Cage: apps/gateway/src, apps/gateway/__tests__, packages/core, md/day6, scripts.
No new deps. Keep Day4/Day5 tests green.
Follow API_CONTRACT_DAY6.md and IMPLEMENTATION_GUIDE.md.
Write tests in apps/gateway/__tests__/retry_notify.test.ts.
