# Day 6 — Context

Goal: Retry & Idempotency (bodyHash) + Notifications on approval state changes (approved/denied/expired). Backend-only. Keep Day4/Day5 tests green.
