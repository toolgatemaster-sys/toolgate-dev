# Day 6 — Testing Template

```
vitest run apps/gateway/__tests__/retry_notify.test.ts
```
Cases:
1) First request → 202 pending
2) Approve → retry same bodyHash → 200
3) Deny → retry same bodyHash → 403
4) Expire → retry same bodyHash → 403
5) Notification fired on approve/deny/expire (mock)
