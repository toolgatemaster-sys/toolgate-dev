# Day 6 — API Contract (Retry + Notifications)

## Retry
- Same request (same `bodyHash`) after approval:
  - approved → allow (200)
  - denied/expired → 403
  - pending → 202 (reuse approval_id)

## Notifications
- Env: `TOOLGATE_WEBHOOK_URL` (optional).
- POST JSON on status changes: { id, status, agentId, ctx, ts }.
- Log failures; do not block flow.
