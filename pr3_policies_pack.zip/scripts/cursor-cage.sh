#!/bin/bash
set -e
CAGE_DIR="scripts/cages"
case "$1" in
  on)
    git sparse-checkout init --cone
    git sparse-checkout set $(cat "$CAGE_DIR/$2.txt")
    ;;
  off)
    git sparse-checkout disable
    ;;
  list)
    ls $CAGE_DIR/*.txt | sed 's#.*/##;s/.txt$//'
    ;;
  *)
    echo "Usage: $0 [on profile|off|list]"
    ;;
esac
