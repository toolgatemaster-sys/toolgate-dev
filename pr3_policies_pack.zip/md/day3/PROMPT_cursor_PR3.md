# Cursor Instructions — PR3 (Policies)
Read ONLY: md/day3/PR3_policies.md

Rules:
- Branch: feat/policies
- Only touch: packages/core, apps/collector/src+tests, apps/gateway/src+tests, md/day3
- No deps, no config changes
- Implement exactly spec in PR3_policies.md
