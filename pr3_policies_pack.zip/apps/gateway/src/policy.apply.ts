// TODO: implement applyPolicy in PR3
