#!/bin/bash
set -e
CAGE_DIR="scripts/cages"
case "$1" in
  on)
    profile="$2"; test -n "$profile" || { echo "Usage: $0 on <profile>"; exit 1; }
    test -f "$CAGE_DIR/$profile.txt" || { echo "❌ Profile not found: $profile"; exit 1; }
    echo "🔒 Activating cage profile: $profile"
    git sparse-checkout init --cone
    git sparse-checkout set $(cat "$CAGE_DIR/$profile.txt")
    echo "✅ Cage '$profile' activated."
    ;;
  off)
    echo "🔓 Disabling cage..."
    git sparse-checkout disable
    echo "✅ Cage disabled."
    ;;
  list)
    echo "📂 Profiles:"
    ls -1 "$CAGE_DIR"/*.txt 2>/dev/null | sed 's#.*/##;s/\.txt$//'
    ;;
  *)
    echo "Usage: $0 [on <profile>|off|list]"; exit 1;
    ;;
esac
