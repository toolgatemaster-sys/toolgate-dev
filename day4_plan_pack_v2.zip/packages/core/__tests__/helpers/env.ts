export const TEST_CLIENT_HMAC = process.env.TOOLGATE_CLIENT_HMAC_KEY || "dev-client-key";
