import crypto from "node:crypto";
export function sign(body: unknown, key: string, header = "x-toolgate-client-sig") {
  const payload = typeof body === "string" ? body : JSON.stringify(body);
  const sig = crypto.createHmac("sha256", key).update(payload).digest("hex");
  return { [header]: sig, "content-type": "application/json" as const };
}
