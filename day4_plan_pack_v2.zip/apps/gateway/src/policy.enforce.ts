// Stub: registerEnforcement — Cursor will implement following the ENFORCE_POLICY_SNIPPET.md
import type { FastifyInstance } from "fastify";
export async function registerEnforcement(app: FastifyInstance) {
  // TODO: implement in PR4 (use applyPolicy(ctx, action))
}
